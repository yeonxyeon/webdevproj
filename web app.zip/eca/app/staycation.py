from app import db

class STAYCATION(db.Document):    
    meta = {'collection' : 'staycation'}            # Naming collection as 'staycation'
    hotel_name = db.StringField(max_length=30)      # (Package name) String field with max character limit at 30
    duration = db.IntField()                        # (Package duration) Integer field with 32bit integer, only can input numbers
    unit_cost = db.FloatField()                     # (Package cost price) Float field, consists of number with decimal
    image_url = db.StringField(max_length=30)       # (Package image link) String field with max character limit at 30
    description = db.StringField(max_length=500)    # (Package description) String field with max character limit at 500


