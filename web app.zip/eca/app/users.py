from app import db
from flask_login import UserMixin

class User(UserMixin, db.Document):       # UserMixin: Implementation of Flask-login properties
    
    meta = {'collection': 'appUsers'}     # Name the collection as 'appUsers'

    email = db.StringField(max_length=30) # (User email address) String field with max character limit at 30
    password = db.StringField()           # (User password) String field
    name = db.StringField()               # (User name) String field
