# https://medium.com/@dmitryrastorguev/basic-user-authentication-login-for-flask-using-mongoengine-and-wtforms-922e64ef87fe

from flask_login import login_required, current_user
from flask import render_template, request
from app import app, db, login_manager
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta, date

from auth import auth
from dashboard import dashboard
from users import User
from staycation import STAYCATION
from book import Booking

import csv
import io

# register blueprint from respective module
app.register_blueprint(auth)
app.register_blueprint(dashboard)

# Load the current user if any
@login_manager.user_loader
def load_user(user_id):
    return User.objects(pk=user_id).first()

# Routes to sites
@app.route('/base')
def show_base():
    return render_template('base.html')


@app.route('/home')
@login_required
def show_home():
    stayCationObject = STAYCATION.objects() #retrieve from db
    return render_template('packages.html',panel = "Packages",stayCationObject = stayCationObject)


#Allow users to see the package they selected and book them.
@app.route('/Book')
@login_required
def show_book():
    #Retrieve from parameters from url link 
    name= request.args.get('name')
    image = request.args.get('image')
    desc = request.args.get('desc')

    #Retrieve today date in YYYY-MM-DD Format in String.
    todayDate = datetime.today().strftime('%Y-%m-%d')

    return render_template('booking.html',panel = name,image = image, desc = desc , todayDate = todayDate)



@app.route('/dashboard')
@login_required
def show_dashboard():
    action = request.args.get('action')
    title =  ""
    userList = []

    ## To decide what to display for the card title.
    if action is None :
        title = "Total Income"
    elif action == "duePerUser" :
        title = "Due Per User"
    elif action == "duePerHotel" :
        title = "Due Per Hotel"

    ##Exclude admin from dropdownlist
    for item in User.objects:
        if item['email'] != "admin@abc.com" :
            userList.append(item)

    return render_template('trend_chart.html',panel = "Dashboard", Action = action , Title = title , User = userList , Hotel = STAYCATION.objects())

 
@app.route("/upload", methods=['GET','POST'])
@login_required
def upload():   

    if request.method == 'GET':
        return render_template("upload.html", name=current_user.name, panel="Upload") ## Redirects to upload page for admin to upload data files.

    elif request.method == 'POST': ## Admin is trying to upload a file
        
        typeOfFile = request.form.get('type') ## Retrieve what type of file is uploaded. (User , Staycation or Booking)

        ## Read from file from the Form and decoding it 
        file = request.files.get('file')                    
        data = file.read().decode('utf-8')
        dict_reader = csv.DictReader(io.StringIO(data), delimiter=',', quotechar='"')
        file.close()
        
        if typeOfFile == 'User': #If admin uploads User file

            ## Storing of data in the User  file to the database
            for item in list(dict_reader):
                ## Reading an item from the file
                vEmail = item['email']
                hashpass = generate_password_hash(item['password'], method='sha256') #Hashing of password
                vPassword = hashpass
                vName = item['name']

                ##Creation of User object and storing it into db.
                hey = User(email=vEmail,password=vPassword, name=vName).save()

        elif typeOfFile == 'Staycation': #If admin uploads staycation file

            ## Storing of data in the Staycation file to the database
            for item in list(dict_reader):
                ## Reading an item from the file
                vHotelName = item['hotel_name']
                vDuration = item['duration']
                vUnit_Cost = item['unit_cost']
                vImage_Url = item['image_url']
                vDescription = item['description']

                ##Creation of STAYCATION object and storing it into db.
                hi = STAYCATION(hotel_name = vHotelName , duration = vDuration, unit_cost = vUnit_Cost, image_url = vImage_Url, description = vDescription ).save()

        elif typeOfFile == 'Booking': # If admin uploads Booking file

            ## Storing of data in the Booking file to the database
            for item in list(dict_reader):
                ## Reading an item from the file
                vCheckInDate = item['check_in_date']
                vCustomer = item['customer']
                vHotelName = item['hotel_name']

                ## Using customer email from item to find User object in db.
                find_user = User.objects(email=vCustomer).first()
                ## Using hotel name from item to find STAYCATION object in db.
                find_package = STAYCATION.objects(hotel_name=vHotelName).first()

                ##Creation of a Booking object with details
                bookingObject = Booking(check_in_date = vCheckInDate,customer = find_user,package = find_package,total_cost = 0)

                ##Calling method in Booking Object to update the total_cost for the object.
                bookingObject.calculate_total_cost()

                ## Saving the booking object to the database.
                bookingObject.save()
                
        ## Redirects the admin back to the upload page.
        return render_template("upload.html", name=current_user.name, panel="Upload")

@app.route("/book", methods=['POST'])
@login_required
def book(): #User page , Booking Page

    ##Getting booking details from the form.
    name = request.form.get('name')
    checkInDate = request.form.get('checkInDate')

    ## Using customer email from item to find User object in db.
    find_user = User.objects(email=current_user.email).first()
    
    ## Using hotel name from item to find STAYCATION object in db.
    find_package = STAYCATION.objects(hotel_name=name).first()

    ##Creation of a Booking object with details
    bookingObject = Booking(check_in_date = checkInDate, customer = find_user, package = find_package,total_cost = 0)

    ##Calling method in Booking Object to update the total_cost for the object.
    bookingObject.calculate_total_cost()

    ## Saving the booking object to the database.
    bookingObject.save()
    
    ## Redirects the user back to the home page
    return render_template('packages.html',panel = "Packages",stayCationObject = STAYCATION.objects())