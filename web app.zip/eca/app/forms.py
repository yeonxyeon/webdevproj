from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, DateTimeField, FloatField
from wtforms.validators import Email, Length, InputRequired

class RegForm(FlaskForm): # Flask form : Session secured form with csrf protection
    # Email is a string field with a max character length of 30. Validation is in place to check input and display message is shown if input is incorrect.
    email = StringField('Email',  validators=[InputRequired(), Email(message='Invalid email'), Length(max=30)])
    # Password is a password input field that will not render back like any normal field.
    # Has a validation in place to check input and password should have a length of minimally 5 and maximally 20.
    password = PasswordField('Password', validators=[InputRequired(), Length(min=5, max=20)])
    # Name is a string field, no validation and any input is accepted
    name = StringField('Name')
