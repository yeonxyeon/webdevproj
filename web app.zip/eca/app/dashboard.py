from flask_login import login_required, current_user
from flask import Blueprint, render_template, request,jsonify,json
from app import app, db, login_manager
from datetime import datetime, timedelta, date

from auth import auth
from users import User
from staycation import STAYCATION
from book import Booking

import csv
import io

#Blueprint to allow routing to dashboard.py
dashboard = Blueprint('dashboard', __name__)

#AJAX call for Total Income
@dashboard.route('/getData',methods=['POST'])
@login_required
def getData():
    checkInDate = []
    bookingObjectList = []
    for item in Booking.objects():
        strDate = item['check_in_date'].strftime('%Y-%m-%d')
        checkInDate.append(strDate)
        bookingObject = Booking(check_in_date = strDate,customer = item['customer'].name,package = item['package'].hotel_name,total_cost = item['total_cost'])
        bookingObjectList.append(bookingObject)

    return jsonify({'Booking':bookingObjectList , 'checkInDate' : checkInDate , 'Staycation':STAYCATION.objects()})

#AJAX call for DuePerUser
@dashboard.route('/getDuePerUser', methods=['POST'])
@login_required
def getDuePerUser():
    #Retrieve email from the AJAX call.
    email = request.form['data']
    
    #Declaring of empty lists 
    hotelNames = []
    duePerUserList = []

    #Search for the user object given the email
    check_user = User.objects(email=email).first()

    #Search for the booking object given the user object
    check_bookings = Booking.objects(customer = check_user)

    #Retrieve all the hotel names from the STAYCATION db.
    for item in STAYCATION.objects():
        hotelNames.append(item['hotel_name'])

    #Sort the hotelNames list in alphabetically order. (key=str.casefold will allow both lower and upper caps to be sorted )
    hotelNames = sorted(hotelNames, key=str.casefold)

    #Populating the duePerUserList with the total numbers whereby the user visited each hotel respectively
    for h in hotelNames:
        count = 0
        for item in check_bookings:
            if item['package'].hotel_name == h:
                count = count + 1
        duePerUserList.append(count)

    #Return to ajax call and JSONify the data back to Javascript.
    return jsonify({'hotelNames':hotelNames,'duePerUserList':duePerUserList})

#AJAX call for DuePerHotel
@dashboard.route('/getDuePerHotel', methods=['POST'])
@login_required
def getDuePerHotel():
    #Retrieve hotel name from AJAX call
    hotel_name = request.form['data']

    #Declaring empty lists
    userNames = []
    userObjectList = []
    duePerHotelList = []

    #Search for the STAYCATION object given the hotel name
    check_package = STAYCATION.objects(hotel_name=hotel_name).first() #Assumption : That there are no Hotel with same names ... 

    #Search for the booking object given the STAYCATION object,
    check_bookings = Booking.objects(package = check_package)
    
    # Adding User objects to the list except for the admin
    # Adding User names to the list except for the admin
    for item in User.objects():
        if(item['email'] != "admin@abc.com") :
            userObjectList.append(item)
            userNames.append(item['name'])
    
    #Sorting the list of User objects by their name alphabetically (.lower will lower all their cases and sort them)
    userObjectList = sorted(userObjectList, key=lambda x: x.name.lower())

    #Sorting the list of User names alphabetically. (key=str.casefold will allow both lower and upper caps to be sorted )
    userNames = sorted(userNames, key=str.casefold)
    
    #Populating the userObjectList with the total number whereby the hotel is visited by each user respectively
    for u in userObjectList:
        count = 0
        for item in check_bookings:

            if item['customer'].email == u.email: ## Email comparison because user might have the same name, but email is unique here
                count = count + 1
        
        duePerHotelList.append(count)

    #Return to ajax call and JSONify the data back to Javascript.
    return jsonify({'userNames':userNames,'duePerHotelList':duePerHotelList})
    