from users import User
from staycation import STAYCATION
from app import db

class Booking(db.Document): 
    meta = {'collection' : 'booking'}               # Naming collection as 'booking'
    check_in_date = db.DateTimeField(required=True) # (Check In Date of Booking)Datetime Field allows data to be in date format, compulsory input when inserting to DB
    customer = db.ReferenceField(User)              # (Which User that booked) Reference to User document. Field takes in a User Object
    package = db.ReferenceField(STAYCATION)         # (Package that user booked) Reference to Staycation document. Field takes in a STAYCATION object
    total_cost = db.FloatField()                    # (Consist of total cost of booking) in float field
    
    
    def calculate_total_cost(self):                                             # A method that takes in a booking object,
        self.total_cost = self.package.duration * self.package.unit_cost        # Updates the total cost attribute of the object by taking the
                                                                                # attribute package  ( STAYCATION  object's duration) multiply by the 
                                                                                # attribute package (STAYCATION object's unit_cost). 
