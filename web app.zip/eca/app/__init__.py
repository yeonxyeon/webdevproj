from flask import Flask
from flask_mongoengine import MongoEngine, Document
from flask_login import LoginManager

import pymongo

def create_app():
    app = Flask(__name__)              # Instantiate app as flask object
    app.config['MONGODB_SETTINGS'] = { # To contain all the db settings
        'db':'eca',                    # Setting the db name as "eca"
        'host':'localhost'             # Set up to run locally 
    }
    app.static_folder = 'assets'       #static files (eg. css, data, img, js) are contain in 'assets' folder

    # Instantiate MongoEngine Object
    db = MongoEngine(app)

    app.config['SECRET_KEY'] = '9OLWxND4o83j4K4iuopO'   # Encryption key
    
    # To allow flask and app to work together, load user ID
    login_manager = LoginManager()
    login_manager.init_app(app)

    # Direct user to login page when they first launch the program 
    login_manager.login_view = 'login'

    return app, db, login_manager

app, db, login_manager = create_app()

